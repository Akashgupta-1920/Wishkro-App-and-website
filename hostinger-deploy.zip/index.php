<?php
// Hostinger PHP Fallback for React Router
$request_uri = $_SERVER['REQUEST_URI'];
$request_path = parse_url($request_uri, PHP_URL_PATH);

// List of static assets to bypass
$static_extensions = ['css', 'js', 'png', 'jpg', 'jpeg', 'gif', 'ico', 'svg', 'woff', 'woff2', 'ttf', 'eot', 'json', 'xml'];
$static_paths = ['/assets/', '/_expo/', '/static/', '/favicon.ico', '/manifest.json', '/robots.txt'];

// Check if it's a static file
$is_static = false;
foreach ($static_extensions as $ext) {
    if (preg_match('/\.' . $ext . '$/i', $request_path)) {
        $is_static = true;
        break;
    }
}

foreach ($static_paths as $path) {
    if (strpos($request_path, $path) === 0) {
        $is_static = true;
        break;
    }
}

// If static file, let Apache handle it
if ($is_static) {
    return false;
}

// Serve React app
header('Content-Type: text/html; charset=utf-8');
readfile('index.html');
?>
